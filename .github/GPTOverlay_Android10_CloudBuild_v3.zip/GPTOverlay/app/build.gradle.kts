plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.gptoverlay"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.gptoverlay"
        minSdk = 29
        targetSdk = 29 // Prototype Android 10 only; update for any public distribution.
        versionCode = 1
        versionName = "0.1.0"
    }
}

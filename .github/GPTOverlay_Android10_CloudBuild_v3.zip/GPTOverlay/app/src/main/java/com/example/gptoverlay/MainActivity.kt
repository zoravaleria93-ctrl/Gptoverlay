package com.example.gptoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var endpoint: EditText
    private lateinit var token: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        endpoint = EditText(this).apply {
            hint = "https://server-anda.example/chat"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        token = EditText(this).apply {
            hint = "Token sesi backend (bukan OpenAI API key)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val start = Button(this).apply {
            text = "Aktifkan GPT Overlay"
            setOnClickListener { startIfAllowed() }
        }
        val stop = Button(this).apply {
            text = "Hentikan overlay"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (16 * resources.displayMetrics.density).toInt()
            setPadding(p, p, p, p)
            addView(TextView(this@MainActivity).apply { text = "Alamat backend HTTPS" })
            addView(endpoint)
            addView(TextView(this@MainActivity).apply { text = "Token akses backend" })
            addView(token)
            addView(start)
            addView(stop)
        }
        setContentView(layout)
    }

    private fun startIfAllowed() {
        val url = endpoint.text.toString().trim()
        val key = token.text.toString().trim()
        val validUrl = try {
            val parsed = java.net.URL(url)
            parsed.protocol == "https" && parsed.host.isNotBlank() && parsed.path == "/chat" &&
                parsed.query == null && parsed.ref == null && parsed.userInfo == null
        } catch (_: Exception) { false }
        if (!validUrl || key.isEmpty()) {
            Toast.makeText(this, "Masukkan endpoint HTTPS /chat dan token backend", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            Toast.makeText(this, "Izinkan overlay lalu ketuk Aktifkan lagi", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, OverlayService::class.java).apply {
            putExtra(OverlayService.EXTRA_ENDPOINT, url)
            putExtra(OverlayService.EXTRA_TOKEN, key)
        }
        startForegroundService(intent)
        Toast.makeText(this, "Overlay dimulai", Toast.LENGTH_SHORT).show()
    }
}

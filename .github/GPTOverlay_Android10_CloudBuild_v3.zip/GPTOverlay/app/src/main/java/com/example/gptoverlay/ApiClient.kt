package com.example.gptoverlay

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {
    private val ui = Handler(Looper.getMainLooper())

    fun sendMessage(endpoint: String, token: String, message: String, callback: (Result<String>) -> Unit) {
        Thread {
            var conn: HttpURLConnection? = null
            val outcome = runCatching {
                val url = URL(endpoint)
                require(url.protocol == "https" && url.host.isNotBlank()) { "Endpoint harus HTTPS" }
                conn = url.openConnection() as HttpURLConnection
                conn!!.apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Authorization", "Bearer $token")
                }
                val data = JSONObject().put("message", message).toString().toByteArray(Charsets.UTF_8)
                conn!!.outputStream.use { it.write(data) }
                val status = conn!!.responseCode
                if (status !in 200..299) throw IllegalStateException("HTTP $status")
                val body = conn!!.inputStream.bufferedReader().use { it.readText() }
                JSONObject(body).getString("reply")
            }
            conn?.disconnect()
            ui.post { callback(outcome) }
        }.start()
    }
}

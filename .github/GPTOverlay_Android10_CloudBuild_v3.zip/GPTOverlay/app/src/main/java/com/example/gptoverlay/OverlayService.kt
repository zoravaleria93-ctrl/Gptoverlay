package com.example.gptoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class OverlayService : Service() {
    companion object {
        const val EXTRA_ENDPOINT = "backend_endpoint"
        const val EXTRA_TOKEN = "backend_session_token"
    }
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var endpoint = ""
    private var token = ""
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("overlay", "GPT Overlay", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, "overlay")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("GPT Overlay aktif")
            .setContentText("Kembali ke aplikasi GPT Overlay untuk menghentikan")
            .build()
        startForeground(1, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val newEndpoint = intent?.getStringExtra(EXTRA_ENDPOINT)
        val newToken = intent?.getStringExtra(EXTRA_TOKEN)
        if (newEndpoint.isNullOrBlank() || newToken.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        endpoint = newEndpoint
        token = newToken
        if (bubble == null) showBubble()
        return START_NOT_STICKY
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun showBubble() {
        val view = Button(this).apply { text = "GPT"; setOnClickListener { togglePanel() } }
        val p = WindowManager.LayoutParams(dp(76), dp(60), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.END
        p.x = dp(12)
        p.y = dp(140)
        wm.addView(view, p)
        bubble = view
    }

    private fun togglePanel() {
        if (panel != null) {
            wm.removeView(panel)
            panel = null
            return
        }
        val response = TextView(this).apply { text = "Siap. Ketik pesan untuk GPT."; textSize = 16f }
        val input = EditText(this).apply { hint = "Pesan"; minLines = 2 }
        val send = Button(this).apply { text = "Kirim" }
        val contentRef = arrayOfNulls<View>(1)
        send.setOnClickListener {
            val message = input.text.toString().trim()
            if (message.isBlank()) return@setOnClickListener
            response.text = "Memproses..."
            send.isEnabled = false
            ApiClient.sendMessage(endpoint, token, message) { result ->
                if (panel !== contentRef[0]) return@sendMessage
                send.isEnabled = true
                result.onSuccess { response.text = it; input.text.clear() }
                result.onFailure { response.text = "Gagal: ${it.message}" }
            }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
            addView(TextView(this@OverlayService).apply { text = "GPT Overlay"; textSize = 20f })
            addView(ScrollView(this@OverlayService).apply { addView(response) }, LinearLayout.LayoutParams(-1, dp(180)))
            addView(input)
            addView(send)
            addView(Button(this@OverlayService).apply { text = "Tutup"; setOnClickListener { togglePanel() } })
        }
        contentRef[0] = content
        val width = minOf(dp(340), resources.displayMetrics.widthPixels - dp(24))
        val p = WindowManager.LayoutParams(width, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.CENTER
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        wm.addView(content, p)
        panel = content
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        bubble?.let { wm.removeView(it) }
        panel = null
        bubble = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

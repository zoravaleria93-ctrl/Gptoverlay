import os
from unittest.mock import patch
from fastapi.testclient import TestClient
from server import app

client = TestClient(app)

def test_unconfigured():
    with patch.dict(os.environ, {}, clear=True):
        response = client.post('/chat', json={'message':'halo'})
        assert response.status_code == 503

def test_unauthorized():
    with patch.dict(os.environ, {'BACKEND_TOKEN':'valid'}, clear=True):
        response = client.post('/chat', json={'message':'halo'}, headers={'Authorization':'Bearer invalid'})
        assert response.status_code == 401

def test_success_mock():
    with patch.dict(os.environ, {'BACKEND_TOKEN':'valid'}, clear=True), patch('server.openai_reply', return_value='Waalaikumussalam') as mocked:
        response = client.post('/chat', json={'message':'Assalamualaikum'}, headers={'Authorization':'Bearer valid'})
        assert response.status_code == 200
        assert response.json() == {'reply':'Waalaikumussalam'}
        mocked.assert_called_once_with('Assalamualaikum')

def test_empty_message():
    with patch.dict(os.environ, {'BACKEND_TOKEN':'valid'}, clear=True):
        response = client.post('/chat', json={'message':''}, headers={'Authorization':'Bearer valid'})
        assert response.status_code == 422

def test_upstream_error_hidden():
    with patch.dict(os.environ, {'BACKEND_TOKEN':'valid'}, clear=True), patch('server.openai_reply', side_effect=RuntimeError('private diagnostic')):
        response = client.post('/chat', json={'message':'halo'}, headers={'Authorization':'Bearer valid'})
        assert response.status_code == 502
        assert 'private diagnostic' not in response.text

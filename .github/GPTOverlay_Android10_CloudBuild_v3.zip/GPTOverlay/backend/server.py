"""Prototype backend. Place behind HTTPS reverse proxy and rate limits."""
import os
import secrets
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="GPT Overlay backend")

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)


def openai_reply(message: str) -> str:
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    response = client.responses.create(model=os.environ.get("OPENAI_MODEL", "gpt-5"), input=message)
    return response.output_text


@app.post("/chat")
def chat(request: ChatRequest, authorization: str = Header(default="")):
    key = os.environ.get("BACKEND_TOKEN")
    if not key:
        raise HTTPException(status_code=503, detail="Backend not configured")
    if not secrets.compare_digest(authorization, f"Bearer {key}"):
        raise HTTPException(status_code=401, detail="Unauthorized")
    try:
        return {"reply": openai_reply(request.message)}
    except Exception:
        raise HTTPException(status_code=502, detail="AI service unavailable")

# GPT Overlay Android 10 prototype

Native Kotlin overlay bubble, chat panel and HTTPS FastAPI backend. No Accessibility or screen capture.

## Backend local tests
```sh
cd backend
python -m pytest -q tests
```

## Backend deployment
Install `pip install -r requirements.txt`; set environment variables `OPENAI_API_KEY` and `BACKEND_TOKEN` (a long randomly generated credential). Run `uvicorn server:app --host 127.0.0.1 --port 8000` behind a TLS reverse proxy with authentication/rate limits. Do **not** expose plain HTTP publicly or hardcode API secrets in the APK.

## Android build
On a machine or Android IDE with Android SDK API 35, build-tools, JDK 17+ and Gradle 8.7+ / Android Gradle Plugin 8.6.1, run `gradle assembleDebug` from the repository root. For a compatible Gradle wrapper, install it separately (`gradle wrapper --gradle-version 8.7`). Output should appear at `app/build/outputs/apk/debug/app-debug.apk` if the build succeeds. This archive does not contain a Gradle wrapper or an APK. Android UI has **not** been tested on a device. Target SDK 29 is only for this Android 10 proof of concept; update for broader Android compatibility and distribution.

## Using the app
Launch the installed app. Enter your deployed HTTPS `/chat` endpoint and backend session credential, enable Draw over other apps permission, then tap Activate again. A GPT bubble appears; tap it to chat. Stop through the main app.

## Security and limitations
This is an early proof of concept. Token is passed transiently to a non-exported Android service and not written to disk; it does not provide real user login, refresh, device attestation, certificate pinning, per-user quotas or production security. Deployment should add those, server rate limiting and abuse protections. The overlay cannot navigate another app, read the screen or access AnyDesk.

## Validation update (2026-11-13)
The overlay chat callback now ignores responses for panels that have since been closed and reopened. MainActivity validates HTTPS URL structure before starting the service. Backend pytest: 5 passed. These source checks do not replace compiling with Android SDK or testing on a phone.

## Build APK tanpa PC melalui GitHub Actions

1. Dari ponsel, buka GitHub dan buat repositori pribadi. Unggah **isi** folder `GPTOverlay` ke akar repositori (termasuk `.github/workflows/build-apk.yml`). Jangan unggah token/backend secret.
2. Buka tab **Actions** > **Build GPT Overlay APK** > **Run workflow**. Workflow juga berjalan pada push ke branch `main`.
3. Setelah job menunjukkan **Success**, buka run tersebut > **Artifacts** > `GPTOverlay-Android10-debug`; unduh ZIP artifact lalu ekstrak `app-debug.apk`.
4. Instal APK dari file manager Android dengan izin instalasi aplikasi dari sumber tersebut. Gunakan hanya APK hasil run milik repositori Anda sendiri.
5. Untuk menguji chat, sediakan backend HTTPS milik Anda yang telah diamankan; jangan pernah memasukkan OpenAI API key ke aplikasi atau repositori.

**Catatan:** Workflow disiapkan tetapi belum dijalankan di GitHub. Kompilasi dan pengujian pada Android belum diverifikasi. Debug APK ditandatangani dengan kunci debug sementara dan hanya untuk uji pribadi. Android 10 mengharuskan izin tampilan di atas aplikasi lain yang diberikan secara manual.
